extends Node2D

var escena_copo: PackedScene

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	escena_copo = load("res://copo.tscn")

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_timer_timeout() -> void:
	var copo = escena_copo.instantiate()
	copo.position.y = -20
	copo.position.x = randi_range(0, 1200)
	add_child(copo)
