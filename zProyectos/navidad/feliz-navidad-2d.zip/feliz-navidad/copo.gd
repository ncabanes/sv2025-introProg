extends Area2D

var velocidadY = 50
var velocidadX = randf_range(-5,5)

func _ready() -> void:
	pass

func _process(delta: float) -> void:
	position.y += velocidadY * delta
	position.x += velocidadX * delta
	if position.y > 800:
		queue_free()
